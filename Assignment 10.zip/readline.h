#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#ifndef readlineH
#define readlineH

int read_line(char str[], int n);
#endif
